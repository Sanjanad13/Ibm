test.skip('renders learn react link', () => {
  // original test code
});
